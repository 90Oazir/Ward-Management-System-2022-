﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Student
    {
        public int UserID { get; set; }

        public Student()
        {
        }
        public Student(int userID)
        {
            UserID = userID;
        }
    }
}
