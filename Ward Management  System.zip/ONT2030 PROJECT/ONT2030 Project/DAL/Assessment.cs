﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Assessments
    {
        public int AssessmentID { get; set; }
        public int StudentLecturerModuleID { get; set; }
        public string DueDate { get; set; }
        public int AssessmentTypeID { get; set; }
        public string AssessmentStatus { get; set; }
        public Assessments() 
        { 
        }
        public Assessments(int assessmentID)
        {
            AssessmentID = assessmentID;
        }
        public Assessments(int assessmentID, int studentLecturerModueID, string dueDate, int assessmentTypeID, string assessmentStatus)
        {
            AssessmentID = assessmentID;
            StudentLecturerModuleID = studentLecturerModueID;
            DueDate = dueDate;
            AssessmentTypeID = assessmentTypeID;
            AssessmentStatus = assessmentStatus;
        }
        public Assessments(int studentLecturerModueID, string dueDate, int assessmentTypeID, string assessmentStatus)
        {
            StudentLecturerModuleID = studentLecturerModueID;
            DueDate = dueDate;
            AssessmentTypeID = assessmentTypeID;
            AssessmentStatus = assessmentStatus;
        }
    }
}