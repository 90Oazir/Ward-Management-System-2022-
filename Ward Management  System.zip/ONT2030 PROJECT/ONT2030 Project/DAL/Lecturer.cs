﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Lecturer
    {
        public int UserID { get; set; }

        public Lecturer()
        {
        }
        public Lecturer(int userID)
        {
            UserID = userID;
        }
    }
}
