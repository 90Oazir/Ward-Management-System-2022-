﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Reflection;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace DAL
{
    public class DataAccessLayer
    {
        static string connString = "Data Source=TSHIFHIWARAMU\\SQLEXPRESS;Initial Catalog=AssessmentDB;Integrated Security=True";
        SqlConnection dbConn = new SqlConnection(connString);
        SqlDataAdapter dbAdapter;
        DataTable dt;
        SqlCommand dbComm;

        public int InsertModuleType(ModuleType moduleType)
        {
            dbComm = new SqlCommand("sp_ModuleTypeInsert", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@moduleTypeDescription", moduleType.ModuleTypeDescription);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public DataTable ListModuleType()
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_ModuleTypeSelect", dbConn);
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int UpdateModuleType(ModuleType moduleType)
        {
            dbComm = new SqlCommand("sp_ModuleTypeUpdate", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@moduleTypeID", moduleType.ModuleTypeID);
            dbComm.Parameters.AddWithValue("@moduleTypeDescription", moduleType.ModuleTypeDescription);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public int DeleteModuleType(ModuleType moduleType)
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_ModuleTypeDelete", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@moduleTypeID", moduleType.ModuleTypeID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }

        public int InsertAssessmentType(AssessmentType assessmentType)
        {
            dbComm = new SqlCommand("sp_AssessmentTypeInsert", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@assessmentTypeDescription", assessmentType.AssessmentTypeDescription);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public DataTable ListAssessmentType()
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_AssessmentTypeSelect", dbConn);
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int UpdateAssessmentType(AssessmentType assessmentType)
        {
            dbComm = new SqlCommand("sp_AssessmentTypeUpdate", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@assessmentTypeID", assessmentType.AssessmentTypeID);
            dbComm.Parameters.AddWithValue("@assessmentTypeDescription", assessmentType.AssessmentTypeDescription);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public int DeleteAssessmentType(AssessmentType assessmentType)
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_AssessmentTypeDelete", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@assessmentTypeID", assessmentType.AssessmentTypeID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public DataTable GetModuleType()
        {
            dbComm = new SqlCommand("sp_GetModuleType", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }

        public int InsertModule(Module module)
        {
            dbComm = new SqlCommand("sp_ModuleInsert", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@moduleName", module.ModuleName);
            dbComm.Parameters.AddWithValue("@moduleDuration", module.ModuleDuration);
            dbComm.Parameters.AddWithValue("@moduleTypeID", module.ModuleTypeID);
            dbComm.Parameters.AddWithValue("@moduleStatus", module.ModuleStatus);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public DataTable ListModule()
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_ModuleSelect", dbConn);
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int UpdateModule(Module module)
        {
            dbComm = new SqlCommand("sp_ModuleUpdate", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@moduleID", module.ModuleID);
            dbComm.Parameters.AddWithValue("@moduleName", module.ModuleName);
            dbComm.Parameters.AddWithValue("@moduleDuration", module.ModuleDuration);
            dbComm.Parameters.AddWithValue("@moduleTypeID", module.ModuleTypeID);
            dbComm.Parameters.AddWithValue("@moduleStatus", module.ModuleStatus);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public int DeleteModule(Module module)
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_ModuleDelete", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@moduleID", module.ModuleID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }

        public int InsertUser(User user, Admin admin, Lecturer lecturer, Student student)
        {
            try
            {
                if (dbConn.State != ConnectionState.Open)
                {
                    dbConn.Open();
                }
            }
            catch { }

            dbComm = new SqlCommand("sp_UserInsert", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@userID", user.UserID);
            dbComm.Parameters.AddWithValue("@name", user.Name);
            dbComm.Parameters.AddWithValue("@surname", user.Surname);
            dbComm.Parameters.AddWithValue("@title", user.Title);
            dbComm.Parameters.AddWithValue("@role", user.Role);
            dbComm.Parameters.AddWithValue("@email", user.Email);
            dbComm.Parameters.AddWithValue("@password", user.Password);
            dbComm.Parameters.AddWithValue("@userStatus", user.UserStatus);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();

            if (user.Role == "Admin")
            {
                try
                {
                    if (dbConn.State != ConnectionState.Open)
                    {
                        dbConn.Open();
                    }
                }
                catch { }
                dbComm = new SqlCommand("sp_AdminIDInsert", dbConn)
                { CommandType = CommandType.StoredProcedure };
                dbComm.Parameters.AddWithValue("@userID", admin.UserID);

                x = dbComm.ExecuteNonQuery();
            }
            else if (user.Role == "Lecturer")
            {
                try
                {
                    if (dbConn.State != ConnectionState.Open)
                    {
                        dbConn.Open();
                    }
                }
                catch { }
                dbComm = new SqlCommand("sp_LecturerIDInsert", dbConn)
                { CommandType = CommandType.StoredProcedure };
                dbComm.Parameters.AddWithValue("@userID", lecturer.UserID);

                x = dbComm.ExecuteNonQuery();
            }
            else if (user.Role == "Student")
            {
                try
                {
                    if (dbConn.State != ConnectionState.Open)
                    {
                        dbConn.Open();
                    }
                }
                catch { }
                dbComm = new SqlCommand("sp_StudentIDInsert", dbConn)
                { CommandType = CommandType.StoredProcedure };
                dbComm.Parameters.AddWithValue("@userID", student.UserID);

                x = dbComm.ExecuteNonQuery();
            }

            dbConn.Close();
            return x;
        }
        public DataTable ListUser()
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_UserSelect", dbConn);
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int UpdateUser(User user)
        {
            dbComm = new SqlCommand("sp_UserUpdate", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@userID", user.UserID);
            dbComm.Parameters.AddWithValue("@name", user.Name);
            dbComm.Parameters.AddWithValue("@surname", user.Surname);
            dbComm.Parameters.AddWithValue("@title", user.Title);
            dbComm.Parameters.AddWithValue("@role", user.Role);
            dbComm.Parameters.AddWithValue("@email", user.Email);
            dbComm.Parameters.AddWithValue("@userStatus", user.UserStatus);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public int DeleteUser(User user)
        {
            try
            {
                if (dbConn.State != ConnectionState.Open)
                {
                    dbConn.Open();
                }
            }
            catch { }
            dbComm = new SqlCommand("sp_UserDelete", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@userID", user.UserID);

            int x = dbComm.ExecuteNonQuery();
            return x;
        }

        public int DeleteAdmin(Admin admin)
        {
            try
            {
                if (dbConn.State != ConnectionState.Open)
                {
                    dbConn.Open();
                }
            }
            catch { }
            dbComm = new SqlCommand("sp_AdminDelete", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@userID", admin.UserID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public int DeleteLecturer(Lecturer lecturer)
        {
            try
            {
                if (dbConn.State != ConnectionState.Open)
                {
                    dbConn.Open();
                }
            }
            catch { }
            dbComm = new SqlCommand("sp_LecturerDelete", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@userID", lecturer.UserID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public int DeleteStudent(Student student)
        {
            try
            {
                if (dbConn.State != ConnectionState.Open)
                {
                    dbConn.Open();
                }
            }
            catch { }
            dbComm = new SqlCommand("sp_StudentDelete", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@userID", student.UserID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }
        public DataTable GetModule()
        {
            dbComm = new SqlCommand("sp_GetModule", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }
        public DataTable GetAdmin()
        {
            dbComm = new SqlCommand("sp_GetAdmin", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }
        public DataTable GetLecturer()
        {
            dbComm = new SqlCommand("sp_GetLecturer", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }
        public DataTable GetStudent()
        {
            dbComm = new SqlCommand("sp_GetStudent", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }

        public int InsertLecturerModule(LecturerModule lecturerModule)
        {
            dbComm = new SqlCommand("sp_LecturerModuleInsert", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@userID", lecturerModule.UserID);
            dbComm.Parameters.AddWithValue("@moduleID", lecturerModule.ModuleID);
            dbComm.Parameters.AddWithValue("@date", lecturerModule.Date);
            dbComm.Parameters.AddWithValue("@modLecturerStatus", lecturerModule.ModLecturerStatus);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public DataTable ListLecturerModule()
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_LecturerModuleSelect", dbConn);
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int UpdateLecturerModule(LecturerModule lecturerModule)
        {
            dbComm = new SqlCommand("sp_LecturerModuleUpdate", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@lecturerModuleID", lecturerModule.LecturerModuleID);
            dbComm.Parameters.AddWithValue("@userID", lecturerModule.UserID);
            dbComm.Parameters.AddWithValue("@moduleID", lecturerModule.ModuleID);
            dbComm.Parameters.AddWithValue("@date", lecturerModule.Date);
            dbComm.Parameters.AddWithValue("@modLecturerStatus", lecturerModule.ModLecturerStatus);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public int DeleteLecturerModule(LecturerModule lecturerModule)
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_LecturerModuleDelete", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@lecturerModuleID", lecturerModule.LecturerModuleID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }

        public int InsertStudentModule(StudentModule studentModule)
        {
            dbComm = new SqlCommand("sp_StudentModuleInsert", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@lecturerModuleID", studentModule.LecturerModuleID);
            dbComm.Parameters.AddWithValue("@userID", studentModule.UserID);
            dbComm.Parameters.AddWithValue("@date", studentModule.Date);
            dbComm.Parameters.AddWithValue("@studModStatus", studentModule.StudModStatus);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public DataTable ListStudentModule()
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_StudentModuleSelect", dbConn);
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int UpdateStudentModule(StudentModule studentModule)
        {
            dbComm = new SqlCommand("sp_StudentModuleUpdate", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@studentModuleID", studentModule.StudentModuleID);
            dbComm.Parameters.AddWithValue("@lecturerModuleID", studentModule.LecturerModuleID);
            dbComm.Parameters.AddWithValue("@userID", studentModule.UserID);
            dbComm.Parameters.AddWithValue("@date", studentModule.Date);
            dbComm.Parameters.AddWithValue("@studModStatus", studentModule.StudModStatus);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public int DeleteStudentModule(StudentModule studentModule)
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_StudentModuleDelete", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@studentModuleID", studentModule.StudentModuleID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }

        public DataTable GetLecturerModule()
        {
            dbComm = new SqlCommand("sp_GetLecturerModule", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }
        public DataTable GetAssessmentType()
        {
            dbComm = new SqlCommand("sp_GetAssessmentType", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }
        public DataTable GetStudentLecturerModule()
        {
            dbComm = new SqlCommand("sp_GetStudentLecturerModule", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }
        public int InsertAssessment(Assessments assessment)
        {
            dbComm = new SqlCommand("sp_AssessmentInsert", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@studentLecturerModuleID", assessment.StudentLecturerModuleID);
            dbComm.Parameters.AddWithValue("@dueDate", assessment.DueDate);
            dbComm.Parameters.AddWithValue("@assessmentTypeID", assessment.AssessmentTypeID);
            dbComm.Parameters.AddWithValue("@assessmentStatus", assessment.AssessmentStatus);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public DataTable ListAssessment()
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_AssessmentSelect", dbConn);
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);
            dbConn.Close();
            return dt;
        }
        public int UpdateAssessment(Assessments assessment)
        {
            dbComm = new SqlCommand("sp_AssessmentUpdate", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@assessmentID", assessment.AssessmentID);
            dbComm.Parameters.AddWithValue("@studentLecturerModuleID", assessment.StudentLecturerModuleID);
            dbComm.Parameters.AddWithValue("@dueDate", assessment.DueDate);
            dbComm.Parameters.AddWithValue("@assessmentTypeID", assessment.AssessmentTypeID);
            dbComm.Parameters.AddWithValue("@assessmentStatus", assessment.AssessmentStatus);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            int x = dbComm.ExecuteNonQuery();
            return x;
        }
        public int DeleteAssessment(Assessments assessment)
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_AssessmentDelete", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@assessmentID", assessment.AssessmentID);

            int x = dbComm.ExecuteNonQuery();
            dbConn.Close();
            return x;
        }

        public DataTable Login(string email, string password)
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_Login", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@Email", email);
            dbComm.Parameters.AddWithValue("@Password", password);
            dt = new DataTable();
            dbAdapter = new SqlDataAdapter(dbComm);
            dbAdapter.Fill(dt);
            return dt;
        }
        public DataTable ModulebyType(int moduleTypeID)
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_GetModulebyType", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@ModuleTypeID", moduleTypeID);
            dt = new DataTable();
            dbAdapter = new SqlDataAdapter(dbComm);
            dbAdapter.Fill(dt);
            return dt;
        }
        public DataTable UserSearch(int userID)
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_UserSearch", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@UserID", userID);
            dt = new DataTable();
            dbAdapter = new SqlDataAdapter(dbComm);
            dbAdapter.Fill(dt);
            return dt;
        }
        public DataTable GetMaxAdminID(Admin admin)
        {
            dbComm = new SqlCommand("sp_GetMaxAdminID", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }
        public DataTable GetMaxLecturerID(Lecturer lecturer)
        {
            dbComm = new SqlCommand("sp_GetMaxLecturerID", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }
        public DataTable GetMaxStudentID(Student student)
        {
            dbComm = new SqlCommand("sp_GetMaxStudentID", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }
        public DataTable GetCompletedAssessment()
        {
            dbComm = new SqlCommand("sp_CompletedAssessment", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }
        public DataTable GetMissedAssessment()
        {
            dbComm = new SqlCommand("sp_MissedAssessment", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }
        public DataTable GetNotYetDueAssessment()
        {
            dbComm = new SqlCommand("sp_NotYetDueAssessment", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbAdapter = new SqlDataAdapter(dbComm);
            dt = new DataTable();
            dbAdapter.Fill(dt);

            if (dbConn.State == ConnectionState.Closed)
            {
                dbConn.Open();
            }
            return dt;
        }
        public DataTable AssessmentbyType(int assessmentTypeID)
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_AssessmentbyType", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@AssessmentTypeID", assessmentTypeID);
            dt = new DataTable();
            dbAdapter = new SqlDataAdapter(dbComm);
            dbAdapter.Fill(dt);
            return dt;
        }
        public DataTable AssessmentbyDate(string startDate, string endDate)
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("sp_AssessmentbyDates", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.Add(new SqlParameter("@StartDate", SqlDbType.NVarChar)).Value = startDate;
            dbComm.Parameters.Add(new SqlParameter("@EndDate", SqlDbType.NVarChar)).Value = endDate;
            dt = new DataTable();
            dbAdapter = new SqlDataAdapter(dbComm);
            dbAdapter.Fill(dt);
            return dt;
        }
        public DataTable ModuleSearch(string module)
        {
            try
            {
                dbConn.Open();
            }
            catch { }
            dbComm = new SqlCommand("SearchModuleDetails", dbConn)
            { CommandType = CommandType.StoredProcedure };
            dbComm.Parameters.AddWithValue("@ModuleName", module);
            dt = new DataTable();
            dbAdapter = new SqlDataAdapter(dbComm);
            dbAdapter.Fill(dt);
            return dt;
        }
    }
}