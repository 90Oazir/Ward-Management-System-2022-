﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessment
{
    public partial class LecturerMenu : Form
    {
        public LecturerMenu()
        {
            InitializeComponent();
        }

        private void btnAssessment_Click(object sender, EventArgs e)
        {
            frmAssessmentType form = new frmAssessmentType();
            form.Show();
            this.Hide();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            LecturerReport form = new LecturerReport();
            form.Show();
            this.Hide();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            Login form = new Login();
            form.Show();
            this.Hide();
        }
        DataTable dt = Login.dtInfo;
        private void LecturerMenu_Load(object sender, EventArgs e)
        {
            lblNames.Text = "(" + dt.Rows[0]["Name"].ToString() + ", " + dt.Rows[0]["Surname"].ToString() +
               " (" + dt.Rows[0]["Role"].ToString() + "))";

            lblNames.Visible = true;
        }
    }
}
