﻿namespace Assessment
{
    partial class AdminMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblNames = new System.Windows.Forms.Label();
            this.btnLogOut = new System.Windows.Forms.Button();
            this.btnReports = new System.Windows.Forms.Button();
            this.btnModuleStudent = new System.Windows.Forms.Button();
            this.btnModuleLecturer = new System.Windows.Forms.Button();
            this.btnModuleType = new System.Windows.Forms.Button();
            this.btnModule = new System.Windows.Forms.Button();
            this.btnUsers = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblNames);
            this.groupBox1.Controls.Add(this.btnLogOut);
            this.groupBox1.Controls.Add(this.btnReports);
            this.groupBox1.Controls.Add(this.btnModuleStudent);
            this.groupBox1.Controls.Add(this.btnModuleLecturer);
            this.groupBox1.Controls.Add(this.btnModuleType);
            this.groupBox1.Controls.Add(this.btnModule);
            this.groupBox1.Controls.Add(this.btnUsers);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(760, 437);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Menu";
            // 
            // lblNames
            // 
            this.lblNames.AutoSize = true;
            this.lblNames.Location = new System.Drawing.Point(409, 22);
            this.lblNames.Name = "lblNames";
            this.lblNames.Size = new System.Drawing.Size(167, 20);
            this.lblNames.TabIndex = 23;
            this.lblNames.Text = "Name, Surname(Role)";
            this.lblNames.Visible = false;
            // 
            // btnLogOut
            // 
            this.btnLogOut.Location = new System.Drawing.Point(670, 396);
            this.btnLogOut.Name = "btnLogOut";
            this.btnLogOut.Size = new System.Drawing.Size(84, 35);
            this.btnLogOut.TabIndex = 20;
            this.btnLogOut.Text = "Log out";
            this.btnLogOut.UseVisualStyleBackColor = true;
            this.btnLogOut.Click += new System.EventHandler(this.btnLogOut_Click);
            // 
            // btnReports
            // 
            this.btnReports.Location = new System.Drawing.Point(18, 317);
            this.btnReports.Name = "btnReports";
            this.btnReports.Size = new System.Drawing.Size(245, 36);
            this.btnReports.TabIndex = 5;
            this.btnReports.Text = "Reports";
            this.btnReports.UseVisualStyleBackColor = true;
            this.btnReports.Click += new System.EventHandler(this.btnReports_Click);
            // 
            // btnModuleStudent
            // 
            this.btnModuleStudent.Location = new System.Drawing.Point(18, 264);
            this.btnModuleStudent.Name = "btnModuleStudent";
            this.btnModuleStudent.Size = new System.Drawing.Size(245, 36);
            this.btnModuleStudent.TabIndex = 4;
            this.btnModuleStudent.Text = "Assign Module to Student";
            this.btnModuleStudent.UseVisualStyleBackColor = true;
            this.btnModuleStudent.Click += new System.EventHandler(this.btnModuleStudent_Click);
            // 
            // btnModuleLecturer
            // 
            this.btnModuleLecturer.Location = new System.Drawing.Point(18, 212);
            this.btnModuleLecturer.Name = "btnModuleLecturer";
            this.btnModuleLecturer.Size = new System.Drawing.Size(245, 36);
            this.btnModuleLecturer.TabIndex = 3;
            this.btnModuleLecturer.Text = "Assign Module to Lecturer";
            this.btnModuleLecturer.UseVisualStyleBackColor = true;
            this.btnModuleLecturer.Click += new System.EventHandler(this.btnModuleLecturer_Click);
            // 
            // btnModuleType
            // 
            this.btnModuleType.Location = new System.Drawing.Point(18, 107);
            this.btnModuleType.Name = "btnModuleType";
            this.btnModuleType.Size = new System.Drawing.Size(245, 36);
            this.btnModuleType.TabIndex = 2;
            this.btnModuleType.Text = "Manage Module Type";
            this.btnModuleType.UseVisualStyleBackColor = true;
            this.btnModuleType.Click += new System.EventHandler(this.btnModuleType_Click);
            // 
            // btnModule
            // 
            this.btnModule.Location = new System.Drawing.Point(18, 159);
            this.btnModule.Name = "btnModule";
            this.btnModule.Size = new System.Drawing.Size(245, 36);
            this.btnModule.TabIndex = 1;
            this.btnModule.Text = "Manage Module";
            this.btnModule.UseVisualStyleBackColor = true;
            this.btnModule.Click += new System.EventHandler(this.btnModule_Click);
            // 
            // btnUsers
            // 
            this.btnUsers.Location = new System.Drawing.Point(18, 56);
            this.btnUsers.Name = "btnUsers";
            this.btnUsers.Size = new System.Drawing.Size(245, 36);
            this.btnUsers.TabIndex = 0;
            this.btnUsers.Text = "Manage Users";
            this.btnUsers.UseVisualStyleBackColor = true;
            this.btnUsers.Click += new System.EventHandler(this.btnUsers_Click);
            // 
            // AdminMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "AdminMenu";
            this.Text = "Admin Menu";
            this.Load += new System.EventHandler(this.AdminMenu_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnModule;
        private System.Windows.Forms.Button btnUsers;
        private System.Windows.Forms.Button btnModuleStudent;
        private System.Windows.Forms.Button btnModuleLecturer;
        private System.Windows.Forms.Button btnModuleType;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.Button btnLogOut;
        private System.Windows.Forms.Label lblNames;
    }
}