﻿using BLL;
using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace Assessment
{
    public partial class frmAssessmentType : Form
    {
        public frmAssessmentType()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnBack_Click(object sender, EventArgs e)
        {
            StudentMenu form = new StudentMenu();
            form.Show();
            this.Hide();
        }

        private void txtAssessmentTypeDesc_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtAssessmentTypeDesc.Text))
            {
                e.Cancel = true;
                txtAssessmentTypeDesc.Focus();
                errorProvider.SetError(txtAssessmentTypeDesc, "Please enter the Assessment Type description!");
            }
            else
            {
                e.Cancel = false;
                errorProvider.SetError(txtAssessmentTypeDesc, null);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AssessmentType assessmentType = new AssessmentType(txtAssessmentTypeDesc.Text);

            int x = bll.InsertAssessmentTypes(assessmentType);
            if (x > 0)
            {
                MessageBox.Show(x + " Assessment Type was Added.");
                txtAssessmentTypeDesc.Clear();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            AssessmentType assessmentType = new AssessmentType(int.Parse(dgvAssessmentType.SelectedRows[0].Cells["AssessmentTypeID"].Value.ToString()), txtAssessmentTypeDesc.Text);
            int x = bll.UpdateAssessmentTypes(assessmentType);

            if (x > 0)
            {
                MessageBox.Show(x + " Assessment Type was Updated.");
                txtAssessmentTypeDesc.Clear();
                Display();
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Display();
        }
        public void Display()
        {
            dgvAssessmentType.DataSource = bll.ListAssessmentTypes();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            AssessmentType assessmentType = new AssessmentType(int.Parse(dgvAssessmentType.SelectedRows[0].Cells["AssessmentTypeID"].Value.ToString()));
            int x = bll.DeleteAssessmentTypes(assessmentType);

            if (x > 0)
            {
                MessageBox.Show(x + " Assessment Type was Deleted.");
                txtAssessmentTypeDesc.Clear();
                Display();
            }
        }

        private void dgvAssessmentType_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvAssessmentType.SelectedRows.Count > 0)
            {
                txtAssessmentTypeDesc.Text = dgvAssessmentType.SelectedRows[0].Cells["AssessmentTypeDescription"].Value.ToString();
            }
        }
    }
}
