﻿using BLL;
using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace Assessment
{
    public partial class frmModuleType : Form
    {
        public frmModuleType()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminMenu form = new AdminMenu();
            form.Show();
            this.Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ModuleType moduleType = new ModuleType(txtModuleTypeDesc.Text);

            int x = bll.InsertModuleTypes(moduleType);
            if (x > 0)
            {
                MessageBox.Show(x + " Module Type was Added.");
                txtModuleTypeDesc.Clear();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            ModuleType moduleType = new ModuleType(int.Parse(dgvModuleType.SelectedRows[0].Cells["ModuleTypeID"].Value.ToString()), txtModuleTypeDesc.Text);
            int x = bll.UpdateModuleTypes(moduleType);

            if (x > 0)
            {
                MessageBox.Show(x + " Module Type was Updated.");
                txtModuleTypeDesc.Clear();
                Display();
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Display();
        }
        public void Display()
        {
            dgvModuleType.DataSource = bll.ListModuleTypes();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            ModuleType moduleType = new ModuleType(int.Parse(dgvModuleType.SelectedRows[0].Cells["ModuleTypeID"].Value.ToString()));
            int x = bll.DeleteModuleTypes(moduleType);

            if (x > 0)
            {
                MessageBox.Show(x + " Module Type was Deleted.");
                txtModuleTypeDesc.Clear();
                Display();
            }
        }

        private void dgvModuleType_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void txtModuleTypeDesc_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtModuleTypeDesc.Text))
            {
                e.Cancel = true;
                txtModuleTypeDesc.Focus();
                errorProvider.SetError(txtModuleTypeDesc, "Please enter the Module Type description!");
            }
            else
            {
                e.Cancel = false;
                errorProvider.SetError(txtModuleTypeDesc, null);
            }
        }

        private void dgvModuleType_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvModuleType.SelectedRows.Count > 0)
            {
                txtModuleTypeDesc.Text = dgvModuleType.SelectedRows[0].Cells["ModuleTypeDescription"].Value.ToString();
            }
        }
    }
}
