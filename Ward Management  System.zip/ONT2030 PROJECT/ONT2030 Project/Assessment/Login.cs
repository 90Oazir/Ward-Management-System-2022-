﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using DAL;
using BLL;

namespace Assessment
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        public static DataTable dtInfo;
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            dtInfo = bll.LogIn(txtUsername.Text, txtPassword.Text);
            try
            {
                string role = dtInfo.Rows[0]["Role"].ToString();

                if (dtInfo.Rows.Count > 0)
                {
                    if (role == "Admin")
                    {
                        AdminMenu form = new AdminMenu();
                        form.Show();
                        this.Hide();
                    }
                    else if (role == "Lecturer")
                    {
                        LecturerMenu form = new LecturerMenu();
                        form.Show();
                        this.Hide();
                    }
                    else if (role == "Student")
                    {
                        StudentMenu form = new StudentMenu();
                        form.Show();
                        this.Hide();
                    }
                }
            }
            catch
            {
                lblError.Visible = true;
            }
        }

        private void chbPass_CheckedChanged(object sender, EventArgs e)
        {
            if (chbPass.Checked == true)
            {
                txtPassword.PasswordChar = (char)0;
                chbPass.Text = "Hide";
            }
            else
            {
                txtPassword.PasswordChar = '*';
                chbPass.Text = "Show";
            }
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
