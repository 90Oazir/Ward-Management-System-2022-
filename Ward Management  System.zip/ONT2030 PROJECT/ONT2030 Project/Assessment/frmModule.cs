﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using DAL;
using BLL;

namespace Assessment
{
    public partial class frmModule : Form
    {
        public frmModule()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminMenu form = new AdminMenu();
            form.Show();
            this.Hide();
        }

        private void txtModuleName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtModuleName.Text))
            {
                e.Cancel = true;
                txtModuleName.Focus();
                errorProvider.SetError(txtModuleName, "Please enter the Module Name description!");
            }
            else
            {
                e.Cancel = false;
                errorProvider.SetError(txtModuleName, null);
            }
        }

        private void txtModuleDuration_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtModuleDuration.Text))
            {
                e.Cancel = true;
                txtModuleDuration.Focus();
                errorProvider.SetError(txtModuleDuration, "Please enter the Module Duration description!");
            }
            else
            {
                e.Cancel = false;
                errorProvider.SetError(txtModuleDuration, null);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Module module = new Module(txtModuleName.Text, txtModuleDuration.Text, int.Parse(cmbModuleType.SelectedValue.ToString()), 
                cmbModuleStatus.SelectedItem.ToString());

            int x = bll.InsertModules(module);
            if (x > 0)
            {
                MessageBox.Show(x + " Module was Added.");
                txtModuleName.Clear();
                txtModuleDuration.Clear();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Module module = new Module(int.Parse(dgvModule.SelectedRows[0].Cells["ModuleID"].Value.ToString()), txtModuleName.Text, 
                txtModuleDuration.Text, int.Parse(cmbModuleType.SelectedValue.ToString()), cmbModuleStatus.SelectedItem.ToString());
            int x = bll.UpdateModules(module);

            if (x > 0)
            {
                MessageBox.Show(x + " Module was Updated.");
                txtModuleName.Clear();
                txtModuleDuration.Clear();
                Display();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Module module = new Module(int.Parse(dgvModule.SelectedRows[0].Cells["ModuleID"].Value.ToString()));
            int x = bll.DeleteModules(module);

            if (x > 0)
            {
                MessageBox.Show(x + " Module was Deleted.");
                txtModuleName.Clear();
                txtModuleDuration.Clear();
                Display();
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Display();
        }
        public void Display()
        {
            dgvModule.DataSource = bll.ListModules();
        }

        private void dgvModule_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvModule.SelectedRows.Count > 0)
            {
                txtModuleName.Text = dgvModule.SelectedRows[0].Cells["ModuleName"].Value.ToString();
                txtModuleDuration.Text = dgvModule.SelectedRows[0].Cells["ModuleDuration"].Value.ToString();
                cmbModuleType.Text = dgvModule.SelectedRows[0].Cells["ModuleTypeDescription"].Value.ToString();
                cmbModuleStatus.Text = dgvModule.SelectedRows[0].Cells["ModuleStatus"].Value.ToString();
            }
        }

        private void frmModule_Load(object sender, EventArgs e)
        {
            cmbModuleType.DataSource = bll.GetModuleType();
            cmbModuleType.DisplayMember = "ModuleTypeDescription";
            cmbModuleType.ValueMember = "ModuleTypeID";

            string[] statuses = new string[] { "Available", "Unavailable" };
            cmbModuleStatus.DataSource = statuses;
            cmbModuleStatus.SelectedIndex = 0;
        }
    }
}
