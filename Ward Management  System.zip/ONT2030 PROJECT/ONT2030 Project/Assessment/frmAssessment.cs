﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BLL;

namespace Assessment
{
    public partial class frmAssessment : Form
    {
        public frmAssessment()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnBack_Click(object sender, EventArgs e)
        {
            LecturerMenu form = new LecturerMenu();
            form.Show();
            this.Hide();
        }

        private void frmAssessment_Load(object sender, EventArgs e)
        {
            string[] statuses = new string[] { "Complete", "Missed", "Not-Yet-Due" };
            cmbAssessmentStatus.DataSource = statuses;
            cmbAssessmentStatus.SelectedIndex = 0;

            cmbAssessmentType.DataSource = bll.GetAssessmentType();
            cmbAssessmentType.DisplayMember = "AssessmentTypeDescription";
            cmbAssessmentType.ValueMember = "AssessmentTypeID";

            cmbStudentLecturerModule.DataSource = bll.GetStudentLecturerModule();
            cmbStudentLecturerModule.DisplayMember = "StudentLecturerModule";
            cmbStudentLecturerModule.ValueMember = "StudentModuleID";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Assessments assessment = new Assessments(int.Parse(cmbStudentLecturerModule.SelectedValue.ToString()), dtpDueDate.Text, 
                int.Parse(cmbAssessmentType.SelectedValue.ToString()), cmbAssessmentStatus.SelectedItem.ToString());

            int x = bll.InsertAssessments(assessment);
            if (x > 0)
            {
                MessageBox.Show(x + " Assessment was Completed.");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Assessments assessment = new Assessments(int.Parse(dgvAssessment.SelectedRows[0].Cells["AssessmentID"].Value.ToString()),
                int.Parse(cmbStudentLecturerModule.SelectedValue.ToString()), dtpDueDate.Text, int.Parse(cmbAssessmentType.SelectedValue.ToString()), cmbAssessmentStatus.SelectedItem.ToString());

            int x = bll.UpdateAssessments(assessment);

            if (x > 0)
            {
                MessageBox.Show(x + " Assessment was Updated.");
                Display();
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Display();
        }
        public void Display()
        {
            dgvAssessment.DataSource = bll.ListAssessments();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Assessments assessment = new Assessments(int.Parse(dgvAssessment.SelectedRows[0].Cells["AssessmentID"].Value.ToString()));

            int x = bll.DeleteAssessments(assessment);

            if (x > 0)
            {
                MessageBox.Show(x + " Assessment was deleted.");
                Display();
            }
        }

        private void dgvAssessment_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvAssessment.SelectedRows.Count > 0)
            {
                cmbStudentLecturerModule.Text = dgvAssessment.SelectedRows[0].Cells["StudentLecturerModule"].Value.ToString();
                cmbAssessmentType.Text = dgvAssessment.SelectedRows[0].Cells["AssessmentTypeDescription"].Value.ToString();
                dtpDueDate.Text = dgvAssessment.SelectedRows[0].Cells["DueDate"].Value.ToString();
                cmbAssessmentStatus.Text = dgvAssessment.SelectedRows[0].Cells["AssessmentStatus"].Value.ToString();
            }
        }
    }
}
