﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace Assessment
{
    public partial class AdminReport : Form
    {
        public AdminReport()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void AdminReport_Load(object sender, EventArgs e)
        {
            string[] roles = new string[] { "Admin", "Lecturer", "Student" };
            cmbUsersRole.DataSource = roles;
            cmbUsersRole.SelectedIndex = 0;

            cmbModuleType.DataSource = bll.GetModuleType();
            cmbModuleType.DisplayMember = "ModuleTypeDescription";
            cmbModuleType.ValueMember = "ModuleTypeID";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminMenu form = new AdminMenu();
            form.Show();
            this.Hide();
        }

        private void btnAllUsers_Click(object sender, EventArgs e)
        {
            dgvReport.ClearSelection();
            dgvReport.DataSource = bll.ListUsers();
        }

        private void btnAllModules_Click(object sender, EventArgs e)
        {
            dgvReport.ClearSelection();
            dgvReport.DataSource = bll.ListModules();
        }

        private void btnSearchUser_Click(object sender, EventArgs e)
        {
            dgvReport.DataSource = bll.UserSearch(int.Parse(txtUser.Text.ToString()));
        }

        private void btnSearchModule_Click(object sender, EventArgs e)
        {
            dgvReport.DataSource = bll.ModuleSearch(txtModule.Text);
        }

        private void cmbUsersRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbUsersRole.Text == "Admin")
            {
                dgvReport.ClearSelection();
                dgvReport.DataSource = bll.GetAdmin();
            }
            else if (cmbUsersRole.Text == "Lecturer")
            {
                dgvReport.ClearSelection();
                dgvReport.DataSource = bll.GetLecturer();
            }
            else if (cmbUsersRole.Text == "Student")
            {
                dgvReport.ClearSelection();
                dgvReport.DataSource = bll.GetStudent();
            }
        }

        private void cmbModuleType_SelectedIndexChanged(object sender, EventArgs e)
        {
            int m;
            Int32.TryParse(cmbModuleType.SelectedValue.ToString(), out m);
            dgvReport.DataSource = bll.ModulebyType(m);
        }
    }
}
