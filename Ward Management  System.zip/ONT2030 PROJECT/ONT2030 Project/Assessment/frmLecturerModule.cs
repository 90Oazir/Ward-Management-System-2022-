﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using BLL;
using DAL;

namespace Assessment
{
    public partial class frmLecturerModule : Form
    {
        public frmLecturerModule()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminMenu form = new AdminMenu();
            form.Show();
            this.Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            LecturerModule lecturerModule = new LecturerModule(int.Parse(cmbLecturer.SelectedValue.ToString()), int.Parse(cmbModule.SelectedValue.ToString()),
                dtpDate.Text, cmbModuleLecturerStatus.SelectedItem.ToString());

            int x = bll.InsertLecturerModules(lecturerModule);
            if (x > 0)
            {
                MessageBox.Show(x + " Lecturer was assigned to a module.");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            LecturerModule lecturerModule = new LecturerModule(int.Parse(dgvLecturerModule.SelectedRows[0].Cells["LecturerModuleID"].Value.ToString()),
                int.Parse(cmbLecturer.SelectedValue.ToString()), int.Parse(cmbModule.SelectedValue.ToString()), dtpDate.Text, cmbModuleLecturerStatus.SelectedItem.ToString());
            
            int x = bll.UpdateLecturerModules(lecturerModule);

            if (x > 0)
            {
                MessageBox.Show(x + " Lecturer was Updated to a module.");
                Display();
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Display();
        }
        public void Display()
        {
            dgvLecturerModule.DataSource = bll.ListLecturerModules();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            LecturerModule lecturerModule = new LecturerModule(int.Parse(dgvLecturerModule.SelectedRows[0].Cells["LecturerModuleID"].Value.ToString()));
            
            int x = bll.DeleteLecturerModules(lecturerModule);

            if (x > 0)
            {
                MessageBox.Show(x + " Lecturer was deleted to a module.");
                Display();
            }
        }

        private void dgvLecturerModule_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvLecturerModule.SelectedRows.Count > 0)
            {
                cmbLecturer.Text = dgvLecturerModule.SelectedRows[0].Cells["LecturerName"].Value.ToString();
                cmbModule.Text = dgvLecturerModule.SelectedRows[0].Cells["ModuleName"].Value.ToString();
                dtpDate.Text = dgvLecturerModule.SelectedRows[0].Cells["Date"].Value.ToString();
                cmbModuleLecturerStatus.Text = dgvLecturerModule.SelectedRows[0].Cells["ModLecturerStatus"].Value.ToString();
            }
        }

        private void frmLecturerModule_Load(object sender, EventArgs e)
        {
            string[] statuses = new string[] { "Active", "In-Active" };
            cmbModuleLecturerStatus.DataSource = statuses;
            cmbModuleLecturerStatus.SelectedIndex = 0;

            cmbModule.DataSource = bll.GetModule();
            cmbModule.DisplayMember = "ModuleName";
            cmbModule.ValueMember = "ModuleID";

            cmbLecturer.DataSource = bll.GetLecturer();
            cmbLecturer.DisplayMember = "LecturerName";
            cmbLecturer.ValueMember = "UserID";
        }
    }
}
