﻿using DAL;
using BLL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessment
{
    public partial class frmStudentModule : Form
    {
        public frmStudentModule()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminMenu form = new AdminMenu();
            form.Show();
            this.Hide();
        }

        private void frmStudentModule_Load(object sender, EventArgs e)
        {
            string[] statuses = new string[] { "Active", "In-Active" };
            cmbStudentModuleStatus.DataSource = statuses;
            cmbStudentModuleStatus.SelectedIndex = 0;

            cmbLecturerModule.DataSource = bll.GetLecturerModule();
            cmbLecturerModule.DisplayMember = "LecturerModule";
            cmbLecturerModule.ValueMember = "LecturerModuleID";

            cmbStudent.DataSource = bll.GetStudent();
            cmbStudent.DisplayMember = "StudentName";
            cmbStudent.ValueMember = "UserID";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            StudentModule studentModule = new StudentModule(int.Parse(cmbLecturerModule.SelectedValue.ToString()), int.Parse(cmbStudent.SelectedValue.ToString()),
               dtpDate.Text, cmbStudentModuleStatus.SelectedItem.ToString());

            int x = bll.InsertStudentModules(studentModule);
            if (x > 0)
            {
                MessageBox.Show(x + " Student was assigned to a module.");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            StudentModule studentModule = new StudentModule(int.Parse(dgvStudentModule.SelectedRows[0].Cells["StudentModuleID"].Value.ToString()),
                int.Parse(cmbLecturerModule.SelectedValue.ToString()), int.Parse(cmbStudent.SelectedValue.ToString()), dtpDate.Text, 
                cmbStudentModuleStatus.SelectedItem.ToString());

            int x = bll.UpdateStudentModules(studentModule);

            if (x > 0)
            {
                MessageBox.Show(x + " Student was Updated to a module.");
                Display();
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Display();
        }
        public void Display()
        {
            dgvStudentModule.DataSource = bll.ListStudentModules();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            StudentModule studentModule = new StudentModule(int.Parse(dgvStudentModule.SelectedRows[0].Cells["StudentModuleID"].Value.ToString()));

            int x = bll.DeleteStudentModules(studentModule);

            if (x > 0)
            {
                MessageBox.Show(x + " Student was deleted to a module.");
                Display();
            }
        }

        private void dgvStudentModule_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvStudentModule.SelectedRows.Count > 0)
            {
                cmbLecturerModule.Text = dgvStudentModule.SelectedRows[0].Cells["LecturerModule"].Value.ToString();
                cmbStudent.Text = dgvStudentModule.SelectedRows[0].Cells["StudentName"].Value.ToString();
                dtpDate.Text = dgvStudentModule.SelectedRows[0].Cells["Date"].Value.ToString();
                cmbStudentModuleStatus.Text = dgvStudentModule.SelectedRows[0].Cells["StudModStatus"].Value.ToString();
            }
        }
    }
}
