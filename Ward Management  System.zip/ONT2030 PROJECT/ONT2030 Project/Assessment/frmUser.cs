﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DAL;

namespace Assessment
{
    public partial class frmUser : Form
    {
        public frmUser()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();
        DataAccessLayer dal = new DataAccessLayer();

        private void btnBack_Click(object sender, EventArgs e)
        {
            AdminMenu form = new AdminMenu();
            form.Show();
            this.Hide();
        }

        private void frmUser_Load(object sender, EventArgs e)
        {
            string[] titles = new string[] { "Mr", "Mrs", "Ms", "Miss", "Dr", "Prof" };
            cmbTitle.DataSource = titles;
            cmbTitle.SelectedIndex = 0;

            string[] roles = new string[] { "Admin", "Lecturer", "Student" };
            cmbRole.DataSource = roles;
            cmbRole.SelectedIndex = 0;

            string[] statuses = new string[] { "Active", "In-Active" };
            cmbUserStatus.DataSource = statuses;
            cmbUserStatus.SelectedIndex = 0;
        }

        private void txtName_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text))
            {
                e.Cancel = true;
                txtName.Focus();
                errorProvider.SetError(txtName, "Please enter the name!");
            }
            else
            {
                e.Cancel = false;
                errorProvider.SetError(txtName, null);
            }
        }

        private void txtSurname_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtSurname.Text))
            {
                e.Cancel = true;
                txtSurname.Focus();
                errorProvider.SetError(txtSurname, "Please enter the surname!");
            }
            else
            {
                e.Cancel = false;
                errorProvider.SetError(txtSurname, null);
            }
        }

        private void txtEmail_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtEmail.Text) || (!Regex.IsMatch(txtEmail.Text, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$")))
            {
                errorProvider.SetError(txtEmail, "Please enter correct email address!");
            }
        }

        private void txtPassword_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(txtPassword.Text))
            {
                e.Cancel = true;
                txtPassword.Focus();
                errorProvider.SetError(txtPassword, "Please enter the password!");
            }
            else
            {
                e.Cancel = false;
                errorProvider.SetError(txtPassword, null);
            }
        }
        
        private void btnAdd_Click(object sender, EventArgs e)
        {
            User user = new User(int.Parse(txtUserID.Text), txtName.Text, txtSurname.Text, cmbTitle.SelectedItem.ToString(),
                    cmbRole.SelectedItem.ToString(), txtEmail.Text, txtPassword.Text, cmbUserStatus.SelectedItem.ToString());

            if (cmbRole.Text == "Admin")
            {
                Admin admin = new Admin(int.Parse(txtUserID.Text));
                Lecturer lecturer = new Lecturer();
                Student student = new Student();
                int x = bll.InsertUsers(user, admin, lecturer, student);
                if (x > 0)
                {
                    MessageBox.Show(x + " User was Added.");
                    ClearText();
                }
            }
            else if (cmbRole.Text == "Lecturer")
            {
                Admin admin = new Admin();
                Lecturer lecturer = new Lecturer(int.Parse(txtUserID.Text));
                Student student = new Student();
                int x = bll.InsertUsers(user, admin, lecturer, student);
                if (x > 0)
                {
                    MessageBox.Show(x + " User was Added.");
                    ClearText();
                }
            }
            else if (cmbRole.Text == "Student")
            {
                Admin admin = new Admin();
                Lecturer lecturer = new Lecturer();
                Student student = new Student(int.Parse(txtUserID.Text));
                int x = bll.InsertUsers(user, admin, lecturer, student);
                if (x > 0)
                {
                    MessageBox.Show(x + " User was Added.");
                    ClearText();
                }
            }
        }
        public void ClearText()
        {
            txtName.Text = "";
            txtSurname.Text = "";
            txtEmail.Text = "";
            txtPassword.Text = "";
            txtPassword.Enabled = true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            User user = new User(int.Parse(dgvUsers.SelectedRows[0].Cells["UserID"].Value.ToString()), txtName.Text, txtSurname.Text, 
                cmbTitle.SelectedItem.ToString(), cmbRole.SelectedItem.ToString(), txtEmail.Text, cmbUserStatus.SelectedItem.ToString());

            int x = bll.UpdateUsers(user);

            if (x > 0)
            {
                MessageBox.Show(x + " User was Updated.");
                ClearText();
                Display();
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            Display();
        }
        public void Display()
        {
            dgvUsers.DataSource = bll.ListUsers();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            User user = new User(int.Parse(dgvUsers.SelectedRows[0].Cells["UserID"].Value.ToString()));

            if (cmbRole.Text == "Admin")
            {
                Admin admin = new Admin(int.Parse(txtUserID.Text));
                int x = bll.DeleteAdmins(admin);
                if (x > 0)
                {
                    int y = bll.DeleteUsers(user);
                    if (y > 0)
                    {
                        MessageBox.Show(y + " User was Deleted.");
                    }
                    else
                    {
                        MessageBox.Show("Something went wrong when you were deleting a user.");
                    }
                }
                else
                {
                    MessageBox.Show("Something went wrong when you were deleting a user.");
                }
            }
            else if (cmbRole.Text == "Lecturer")
            {
                Lecturer lecturer = new Lecturer(int.Parse(txtUserID.Text));
                int x = bll.DeleteLecturers(lecturer);
                if (x > 0)
                {
                    int y = bll.DeleteUsers(user);
                    if (y > 0)
                    {
                        MessageBox.Show(y + " User was Deleted.");
                    }
                    else
                    {
                        MessageBox.Show("Something went wrong when you were deleting a user.");
                    }
                }
                else
                {
                    MessageBox.Show("Something went wrong when you were deleting a user.");
                }
            }
            else if (cmbRole.Text == "Student")
            {
                Student student = new Student(int.Parse(txtUserID.Text));
                int x = bll.DeleteStudents(student);
                if (x > 0)
                {
                    int y = bll.DeleteUsers(user);
                    if (y > 0)
                    {
                        MessageBox.Show(y + " User was Deleted.");
                    }
                    else
                    {
                        MessageBox.Show("Something went wrong when you were deleting a user.");
                    }
                }
                else
                {
                    MessageBox.Show("Something went wrong when you were deleting a user.");
                }
            }

            ClearText();
            Display();
        }
        private void dgvUsers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvUsers.SelectedRows.Count > 0)
            {
                txtUserID.Text = dgvUsers.SelectedRows[0].Cells["UserID"].Value.ToString();
                txtName.Text = dgvUsers.SelectedRows[0].Cells["Name"].Value.ToString();
                txtSurname.Text = dgvUsers.SelectedRows[0].Cells["Surname"].Value.ToString();
                cmbTitle.Text = dgvUsers.SelectedRows[0].Cells["Title"].Value.ToString();
                cmbRole.Text = dgvUsers.SelectedRows[0].Cells["Role"].Value.ToString();
                txtEmail.Text = dgvUsers.SelectedRows[0].Cells["Email"].Value.ToString();
                txtPassword.Enabled = false;
                cmbUserStatus.Text = dgvUsers.SelectedRows[0].Cells["UserStatus"].Value.ToString();
            }
        }

        private void cmbRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbRole.Text == "Admin")
            {
                DataTable dt = new DataTable();
                Admin admin = new Admin();

                dt = bll.GetMaxAdminID(admin);

                int userID= int.Parse(dt.Rows[0]["MaxID"].ToString());
                userID += 1;
                txtUserID.Text = userID.ToString();
            }
            else if (cmbRole.Text == "Lecturer")
            {
                DataTable dt = new DataTable();
                Lecturer lecturer = new Lecturer();

                dt = bll.GetMaxLecturerID(lecturer);
                int userID = int.Parse(dt.Rows[0]["MaxID"].ToString());

                if (userID == 0)
                {
                    userID = 400000;
                    txtUserID.Text = userID.ToString();
                }
                else
                {
                    userID += 1;
                    txtUserID.Text = userID.ToString();
                }
            }
            else if (cmbRole.Text == "Student")
            {
                DataTable dt = new DataTable();
                Student student = new Student();

                dt = bll.GetMaxStudentID(student);
                int userID = int.Parse(dt.Rows[0]["MaxID"].ToString());

                if (userID == 0)
                {
                    userID = 200000000;
                    txtUserID.Text = userID.ToString();
                }
                else
                {
                    userID += 1;
                    txtUserID.Text = userID.ToString();
                }
            }
        }
    }
}
