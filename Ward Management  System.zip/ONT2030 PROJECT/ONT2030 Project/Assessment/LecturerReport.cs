﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace Assessment
{
    public partial class LecturerReport : Form
    {
        public LecturerReport()
        {
            InitializeComponent();
        }
        BusinessLogicLayer bll = new BusinessLogicLayer();

        private void btnAssessment_Click(object sender, EventArgs e)
        {
            dgvReport.DataSource = bll.ListAssessments();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            LecturerMenu form = new LecturerMenu();
            form.Show();
            this.Hide();
        }

        private void LecturerReport_Load(object sender, EventArgs e)
        {
            string[] statuses = new string[] { "Complete", "Missed", "Not-Yet-Due" };
            cmbAssessmentStatus.DataSource = statuses;
            cmbAssessmentStatus.SelectedIndex = 0;

            cmbAssessmentType.DataSource = bll.GetAssessmentType();
            cmbAssessmentType.DisplayMember = "AssessmentTypeDescription";
            cmbAssessmentType.ValueMember = "AssessmentTypeID";
        }

        private void cmbAssessmentStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbAssessmentStatus.Text == "Complete")
            {
                dgvReport.ClearSelection();
                dgvReport.DataSource = bll.GetCompletedAssessments();
            }
            else if (cmbAssessmentStatus.Text == "Missed")
            {
                dgvReport.ClearSelection();
                dgvReport.DataSource = bll.GetMissedAssessments();
            }
            else if (cmbAssessmentStatus.Text == "Not-Yet-Due")
            {
                dgvReport.ClearSelection();
                dgvReport.DataSource = bll.GetNotYetDueAssessments();
            }
        }

        private void cmbAssessmentType_SelectedIndexChanged(object sender, EventArgs e)
        {
            int m;
            Int32.TryParse(cmbAssessmentType.SelectedValue.ToString(), out m);
            dgvReport.DataSource = bll.AssessmentsbyType(m);
        }

        private void btnDate_Click(object sender, EventArgs e)
        {
            dgvReport.DataSource = bll.AssessmentbyDates(dtpFirstDate.Text, dtpLastDate.Text);
        }
    }
}
