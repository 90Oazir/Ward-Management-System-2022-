﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assessment
{
    public partial class AdminMenu : Form
    {
        public AdminMenu()
        {
            InitializeComponent();
        }
        DataTable dt = Login.dtInfo;
        private void btnUsers_Click(object sender, EventArgs e)
        {
            frmUser form = new frmUser();
            form.Show();
            this.Hide();
        }

        private void btnModuleType_Click(object sender, EventArgs e)
        {
            frmModuleType form = new frmModuleType();
            form.Show();
            this.Hide();
        }

        private void btnModule_Click(object sender, EventArgs e)
        {
            frmModule form = new frmModule();
            form.Show();
            this.Hide();
        }

        private void btnModuleLecturer_Click(object sender, EventArgs e)
        {
            frmLecturerModule form = new frmLecturerModule();
            form.Show();
            this.Hide();
        }

        private void btnModuleStudent_Click(object sender, EventArgs e)
        {
            frmStudentModule form = new frmStudentModule();
            form.Show();
            this.Hide();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            AdminReport form = new AdminReport();
            form.Show();
            this.Hide();
        }

        private void btnLogOut_Click(object sender, EventArgs e)
        {
            Login form = new Login();
            form.Show();
            this.Hide();
        }

        private void AdminMenu_Load(object sender, EventArgs e)
        {
            lblNames.Text = "(" + dt.Rows[0]["Name"].ToString() + ", " + dt.Rows[0]["Surname"].ToString() +
               " (" + dt.Rows[0]["Role"].ToString() + "))";

            lblNames.Visible = true;
        }
    }
}