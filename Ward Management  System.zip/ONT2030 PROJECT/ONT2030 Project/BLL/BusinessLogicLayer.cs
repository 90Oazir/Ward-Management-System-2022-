﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL
{
    public class BusinessLogicLayer
    {
        DataAccessLayer dal = new DataAccessLayer();

        public int InsertModuleTypes(ModuleType moduleType)
        {
            return dal.InsertModuleType(moduleType);
        }
        public DataTable ListModuleTypes()
        {
            return dal.ListModuleType();
        }
        public int UpdateModuleTypes(ModuleType moduleType)
        {
            return dal.UpdateModuleType(moduleType);
        }
        public int DeleteModuleTypes(ModuleType moduleType)
        {
            return dal.DeleteModuleType(moduleType);
        }

        public int InsertAssessmentTypes(AssessmentType assessmentType)
        {
            return dal.InsertAssessmentType(assessmentType);
        }
        public DataTable ListAssessmentTypes()
        {
            return dal.ListAssessmentType();
        }
        public int UpdateAssessmentTypes(AssessmentType assessmentType)
        {
            return dal.UpdateAssessmentType(assessmentType);
        }
        public int DeleteAssessmentTypes(AssessmentType assessmentType)
        {
            return dal.DeleteAssessmentType(assessmentType);
        }

        public DataTable GetModuleType()
        {
            return dal.GetModuleType();
        }
        public DataTable GetModule()
        {
            return dal.GetModule();
        }
        public DataTable GetAdmin()
        {
            return dal.GetAdmin();
        }
        public DataTable GetLecturer()
        {
            return dal.GetLecturer();
        }
        public DataTable GetStudent()
        {
            return dal.GetStudent();
        }
        public DataTable GetLecturerModule()
        {
            return dal.GetLecturerModule();
        }
        public DataTable GetAssessmentType()
        {
            return dal.GetAssessmentType();
        }
        public DataTable GetStudentLecturerModule()
        {
            return dal.GetStudentLecturerModule();
        }

        public int InsertModules(Module module)
        {
            return dal.InsertModule(module);
        }
        public DataTable ListModules()
        {
            return dal.ListModule();
        }
        public int UpdateModules(Module module)
        {
            return dal.UpdateModule(module);
        }
        public int DeleteModules(Module module)
        {
            return dal.DeleteModule(module);
        }

        public int InsertUsers(User user, Admin admin, Lecturer lecturer, Student student)
        {
            return dal.InsertUser(user, admin, lecturer, student);
        }
        public DataTable ListUsers()
        {
            return dal.ListUser();
        }
        public int UpdateUsers(User user)
        {
            return dal.UpdateUser(user);
        }
        public int DeleteUsers(User user)
        {
            return dal.DeleteUser(user);
        }
        public int DeleteAdmins(Admin admin)
        {
            return dal.DeleteAdmin(admin);
        }
        public int DeleteLecturers(Lecturer lecturer)
        {
            return dal.DeleteLecturer(lecturer);
        }
        public int DeleteStudents(Student student)
        {
            return dal.DeleteStudent(student);
        }

        public int InsertLecturerModules(LecturerModule lecturerModule)
        {
            return dal.InsertLecturerModule(lecturerModule);
        }
        public DataTable ListLecturerModules()
        {
            return dal.ListLecturerModule();
        }
        public int UpdateLecturerModules(LecturerModule lecturerModule)
        {
            return dal.UpdateLecturerModule(lecturerModule);
        }
        public int DeleteLecturerModules(LecturerModule lecturerModule)
        {
            return dal.DeleteLecturerModule(lecturerModule);
        }

        public int InsertStudentModules(StudentModule studentModule)
        {
            return dal.InsertStudentModule(studentModule);
        }
        public DataTable ListStudentModules()
        {
            return dal.ListStudentModule();
        }
        public int UpdateStudentModules(StudentModule studentModule)
        {
            return dal.UpdateStudentModule(studentModule);
        }
        public int DeleteStudentModules(StudentModule studentModule)
        {
            return dal.DeleteStudentModule(studentModule);
        }

        public int InsertAssessments(Assessments assessment)
        {
            return dal.InsertAssessment(assessment);
        }
        public DataTable ListAssessments()
        {
            return dal.ListAssessment();
        }
        public int UpdateAssessments(Assessments assessment)
        {
            return dal.UpdateAssessment(assessment);
        }
        public int DeleteAssessments(Assessments assessment)
        {
            return dal.DeleteAssessment(assessment);
        }
        public DataTable LogIn(string email, string password)
        {
            return dal.Login(email, password);
        }
        public DataTable ModulebyType(int moduleTypeID)
        {
            return dal.ModulebyType(moduleTypeID);
        }
        public DataTable UserSearch(int userID)
        {
            return dal.UserSearch(userID);
        }
        public DataTable GetMaxAdminID(Admin admin)
        {
            return dal.GetMaxAdminID(admin);
        }
        public DataTable GetMaxLecturerID(Lecturer lecturer)
        {
            return dal.GetMaxLecturerID(lecturer);
        }
        public DataTable GetMaxStudentID(Student student)
        {
            return dal.GetMaxStudentID(student);
        }
        public DataTable GetCompletedAssessments()
        {
            return dal.GetCompletedAssessment();
        }
        public DataTable GetMissedAssessments()
        {
            return dal.GetMissedAssessment();
        }
        public DataTable GetNotYetDueAssessments()
        {
            return dal.GetNotYetDueAssessment();
        }
        public DataTable AssessmentsbyType(int assessmentTypeID)
        {
            return dal.AssessmentbyType(assessmentTypeID);
        }
        public DataTable AssessmentbyDates(string startDate, string endDate)
        {
            return dal.AssessmentbyDate(startDate, endDate);
        }
        public DataTable ModuleSearch(string module)
        {
            return dal.ModuleSearch(module);
        }
    }
}